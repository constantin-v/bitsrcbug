/**
 *
 * BowmoreMigratedGlobalStyles
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

/* eslint-disable react/prefer-stateless-function */
class BowmoreMigratedGlobalStyles extends React.Component {
    render() {
        return <div />;
    }
}

BowmoreMigratedGlobalStyles.propTypes = {};

export default BowmoreMigratedGlobalStyles;
